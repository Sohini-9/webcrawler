from urllib.request import urlopen
from bs4 import BeautifulSoup

html = urlopen("https://www.wikipedia.org")
bsobject = BeautifulSoup(html.read(),"html.parser")

print(bsobject.h1)   #it is only going to include those objects which have the h1 tag
print(bsobject.title)